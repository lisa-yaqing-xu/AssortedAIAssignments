
#MUST READ
#####################################
# 
# All yours' and your partner's details should go here.
# Repalce NETID_stud1 and NETID_stud2 with your netID,
# Person with NAME John Doe would have NetId something like,
# jdoe NOT 10934123
# NAME should have LAST name first, underscore and then FIRST Name,
# ex: DOE_JOHN
# Second part of tuple is your STONY BROOK Id
# like our friend John Doe has 10934123
# 
#####################################

#####################################
# YOU need to change here
#####################################

studentsDetails = {
"yaqxu": ("Yaqing Xu", "108059610"),

"NETID_stud2": ("NAME", "STONY ID #")
}
